var indexSectionsWithContent =
{
  0: "abcdeimnotux",
  1: "d",
  2: "a",
  3: "dmu",
  4: "cdeimot",
  5: "abceno",
  6: "dx"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Macros"
};

