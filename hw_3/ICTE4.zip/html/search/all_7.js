var searchData=
[
  ['num_5fallocated_0',['num_allocated',['../dynamic__array_8h.html#a02ed6bdf7f1a3aa8eb8cd69171d05723',1,'dynamic_array.h']]]
];
