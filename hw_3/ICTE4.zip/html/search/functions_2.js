var searchData=
[
  ['extend_5fbuffer_0',['extend_buffer',['../dynamic__array_8c.html#a7f382628dc70cf8a74eb940bd897cabb',1,'dynamic_array.c']]]
];
