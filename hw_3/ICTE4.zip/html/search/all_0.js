var searchData=
[
  ['anonymous_5fnamespace_7bunit_5ftests_2ec_7d_0',['anonymous_namespace{unit_tests.c}',['../namespaceanonymous__namespace_02unit__tests_8c_03.html',1,'']]],
  ['arrays_1',['arrays',['../dynamic__array_8h.html#a5578008410fbef89cdb57d8a2f110ee8',1,'dynamic_array.h']]]
];
