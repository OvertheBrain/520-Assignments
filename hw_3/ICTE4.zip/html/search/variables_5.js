var searchData=
[
  ['origin_0',['origin',['../struct_dynamic_array.html#af17b5de4074fb8cec910e0949474a81b',1,'DynamicArray']]]
];
